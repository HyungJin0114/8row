const express = require('express');
const router = express.Router();

const authRouter = require('./auth.router');
const userRouter = require('./user.router');
const storeRouter = require('./store.router');
const menuRouter = require('./menu.router');
const orderRouter = require('./order.router');
const reviewRouter = require('./review.router');

router.use('/', authRouter); //로그인 동현님
router.use('/', userRouter); // 두혁님
router.use('/users', userRouter); // 두혁님
router.use('/stores', storeRouter); // 형진님
router.use('/stores', menuRouter); // 동현님
router.use('/stores', orderRouter); // 현진
router.use('/stores', reviewRouter); // 보류

module.exports = router;
